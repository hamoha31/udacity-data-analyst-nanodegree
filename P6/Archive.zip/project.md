# Project Link:
https://public.tableau.com/views/Titanic_355/Story1?:embed=y&:display_count=yes&publish=yes


# Project Summery:
The dataset contains passengers data who were in the titanic. I found it very good dataset and fun. I sow that most of the women were survived from all classes 1st, 2nd and 3rd. 

The visualization also shows that the most passengers at the first and second classes are from Southampton and Cherbourg. Also, it shows that most Queenstown's citizens are of the third class and most of them died.

# Project Design:
I like basic UI and visualizations, so I made my one like that. 

# Feedback:
My friend Faisal said that I have to select basic colors to make it easy to understand data.

# Resources:
NA